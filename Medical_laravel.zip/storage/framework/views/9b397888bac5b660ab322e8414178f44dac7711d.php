<?php echo $__env->make('website.static.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="page-title" style="background-image: url(images/background/8.jpg);">
    <div class="auto-container">
        <div class="title-outer">
            <h1>استعراض الأطباء</h1>
            <ul class="page-breadcrumb">
                <li><a href="./">الرئيسية</a></li>
                <li>الأطباء</li>
            </ul>
        </div>
    </div>
</section>

<section class="team-section-two alternate alternate2">
    <div class="auto-container">
        <div class="row">
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Team Block -->
            <div class="team-block-two col-lg-4 col-md-6 col-sm-12 wow fadeInUp animated animated" style="visibility: visible; animation-name: fadeInUp;">
                <div class="inner-box">
                    <div class="image-box">
                        <figure class="image"><a href="<?php echo e(route('View-Doctor',$doctor->id)); ?>"><img src="<?php echo e(asset($doctor->image)); ?>" alt=""></a></figure>

                    </div>
                    <div class="info-box">
                        <h5 class="name"><a href="<?php echo e(route('View-Doctor',$doctor->id)); ?>"> <?php echo e($doctor->name); ?> </a></h5>
                        <span class="designation">
                            <a href="<?php echo e(route('View-Majors',$doctor->major_id)); ?>">  <?php echo e($doctor->TheMajor->name); ?></a>
                        </span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($doctors->links()); ?>


        </div>

    </div>
</section>

<?php echo $__env->make('website.static.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Dev\laragon\www\Medical_laravel\resources\views/website/doctors/ViewAllDoctors.blade.php ENDPATH**/ ?>